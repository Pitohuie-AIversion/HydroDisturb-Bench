"""Archive original regression bytes separately from LF display copies."""
import hashlib
import json
from pathlib import Path
import zipfile


root = Path.cwd()
scratch = root / "scratch/m3_branch_pulse_20261105"
output = root / "docs/evidence/m3_branch_pulse_20261105"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


sources = sorted((scratch / "regressions").glob("*"))
sources += [scratch / "run_regressions.py", scratch / "retry_targeted.py", Path(__file__)]
entries = []
archive_path = output / "execution_logs.zip"
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sources:
        raw = path.read_bytes()
        name = path.relative_to(root).as_posix()
        archive.writestr(name, raw)
        entries.append({"path": name, "bytes": len(raw), "sha256": digest(raw)})
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for item in entries:
        raw = archive.read(item["path"])
        assert len(raw) == item["bytes"] and digest(raw) == item["sha256"]

displays = []
for name, source in {
    "offline_regression.stdout.txt": "offline_regression.stdout.txt",
    "targeted_retry.stdout.txt": "targeted_retry.stdout.txt",
    "targeted_first_attempt.stdout.txt": "targeted.stdout.txt",
}.items():
    path = scratch / "regressions" / source
    raw = path.read_bytes()
    content = raw.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")
    write_new(output / name, content)
    displays.append({"path": name, "sha256": digest(content), "bytes": len(content),
                     "native_member": path.relative_to(root).as_posix(),
                     "native_sha256": digest(raw), "transformation": "UTF-8 LF display copy"})

records = {path.stem.replace(".execution", ""): json.loads(path.read_text(encoding="utf-8"))
           for path in (scratch / "regressions").glob("*.execution.json")}
assert records["targeted"]["exit_code"] == 1
assert all(records[name]["exit_code"] == 0 for name in ("targeted_retry", "offline_regression", "ruff", "git_diff_check"))
summary = {
    "status": "PASS_WITH_RETAINED_TRANSIENT_FAILURE",
    "targeted_first_attempt": {"passed": 211, "failed": 1, "pytest_seconds": 11.74,
                                "failure": "Previously accepted sequence roundtrip test: Windows rename WinError 5"},
    "targeted_retry_same_code": {"passed": 212, "failed": 0, "pytest_seconds": 11.24},
    "offline_regression": {"passed": 461, "deselected": 30, "pytest_seconds": 30.29,
                           "selection": "not integration", "includes_targeted_tests": True},
    "limitation": "Windows rename root cause remains unresolved. No production code change between attempts. Old 30 integration tests not run; real new branch solves are separately archived.",
    "records": records,
    "archive": {"path": archive_path.name, "bytes": archive_path.stat().st_size,
                "sha256": digest(archive_path.read_bytes()), "entry_count": len(entries),
                "all_native_member_bytes_verified": True, "files": entries},
    "displays": displays,
}
write_new(output / "regression_summary.json", json_bytes(summary))
print(json.dumps({"status": summary["status"], "archive_entries": len(entries),
                  "archive_bytes": archive_path.stat().st_size}))
