import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

out = Path('scratch/m3_branch_pulse_20261105/regressions')
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-v',
           'tests/test_branch_pulse.py', 'tests/test_branch_evidence.py',
           'tests/test_branch_pulse_runner.py', 'tests/test_field_sequence.py',
           'tests/test_full_field_sampling.py', '--junitxml', str(out / 'targeted_retry.xml')]
assert not (out / 'targeted_retry.stdout.txt').exists()
started = time.time()
p = subprocess.run(command, capture_output=True, env=dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUTF8='1'))
(out / 'targeted_retry.stdout.txt').write_bytes(p.stdout)
(out / 'targeted_retry.stderr.txt').write_bytes(p.stderr)
(out / 'targeted_retry.execution.json').write_text(json.dumps({
    'command': command, 'start_unix': started, 'end_unix': time.time(), 'exit_code': p.returncode,
    'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(p.stderr).hexdigest(),
    'reason': 'One accepted sequence test hit the previously known Windows directory-rename WinError 5; no production code change. Full offline regression already passed, including that test. Original failure retained.'
}, indent=2), encoding='utf8')
print(p.stdout.decode('utf8', errors='replace')[-1000:])
sys.exit(p.returncode)
