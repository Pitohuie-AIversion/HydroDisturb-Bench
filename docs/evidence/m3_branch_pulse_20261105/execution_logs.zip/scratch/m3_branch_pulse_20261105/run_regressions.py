import json
import os
from pathlib import Path
import subprocess
import sys
import time
import hashlib

root = Path.cwd()
out = root / 'scratch/m3_branch_pulse_20261105/regressions'
out.mkdir(exist_ok=False)
env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
commands = {
    'targeted': [sys.executable, '-X', 'utf8', '-m', 'pytest', '-v',
                 'tests/test_branch_pulse.py', 'tests/test_branch_evidence.py',
                 'tests/test_branch_pulse_runner.py', 'tests/test_field_sequence.py',
                 'tests/test_full_field_sampling.py', '--junitxml', str(out / 'targeted.xml')],
    'offline_regression': [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', '-m',
                           'not integration', '--junitxml', str(out / 'offline_regression.xml')],
    'ruff': [str(root / '.venv/Scripts/ruff.exe'), 'check',
             'scripts/run_m3_branch_pulse.py', 'src/hydro_disturb_bench/branch_pulse.py',
             'src/hydro_disturb_bench/branch_evidence.py', 'tests/test_branch_pulse.py',
             'tests/test_branch_evidence.py', 'tests/test_branch_pulse_runner.py'],
    'git_diff_check': ['git', 'diff', '--check'],
}
failed = False
for name, command in commands.items():
    started = time.time()
    proc = subprocess.run(command, cwd=root, capture_output=True, env=env)
    (out / f'{name}.stdout.txt').write_bytes(proc.stdout)
    (out / f'{name}.stderr.txt').write_bytes(proc.stderr)
    record = {'command': command, 'cwd': str(root), 'start_unix': started,
              'end_unix': time.time(), 'exit_code': proc.returncode,
              'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
              'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest()}
    (out / f'{name}.execution.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    print(name, 'exit', proc.returncode, 'elapsed', round(time.time()-started, 2), flush=True)
    print(proc.stdout.decode('utf8', errors='replace')[-800:], flush=True)
    if proc.returncode:
        failed = True
sys.exit(1 if failed else 0)
